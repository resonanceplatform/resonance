"use client";
import { auth } from "@/lib/firebase";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, User } from "firebase/auth";

export async function signUpEmail(email: string, password: string) {
  return createUserWithEmailAndPassword(auth, email, password);
}
export async function signInEmail(email: string, password: string) {
  return signInWithEmailAndPassword(auth, email, password);
}
export async function signOutUser() {
  return signOut(auth);
}
export function watchAuth(cb: (u: User | null) => void) {
  return onAuthStateChanged(auth, cb);
}
