"use client";
import { db } from "@/lib/firebase";
import { collection, doc, setDoc, addDoc, getDocs, query, where, serverTimestamp } from "firebase/firestore";

export async function upsertUser(userId: string, data: any) {
  await setDoc(doc(db, "users", userId), { ...data, createdAt: serverTimestamp() }, { merge: true });
}

export async function upsertProfile(profileId: string, data: any) {
  await setDoc(doc(db, "profiles", profileId), data, { merge: true });
}

export async function listValues() {
  const snap = await getDocs(collection(db, "values"));
  return snap.docs.map(d => ({ id: d.id, ...(d.data() as any) }));
}

export async function getProfileByUserId(userId: string) {
  const q = query(collection(db, "profiles"), where("userId", "==", userId));
  const snap = await getDocs(q);
  return snap.docs[0] ? ({ id: snap.docs[0].id, ...snap.docs[0].data() } as any) : null;
}

export async function createConversation(matchId: string) {
  const ref = await addDoc(collection(db, "conversations"), {
    matchId,
    unlockStage: "text-only",
    createdAt: serverTimestamp(),
    lastActivityAt: serverTimestamp(),
  });
  return ref.id;
}
