# Resonance (MVP Web App)

Starter codebase for the Resonance MVP (conversation-before-appearance).

Tech:
- Next.js (App Router) + TypeScript
- Firebase Auth (email/password)
- Firestore (users, profiles, values, userValues, matches, conversations, messages, verifications, reports)
- Firebase Storage (voice notes, locked photos, fresh checks)

## Run locally
1) Install Node.js 18+
2) In this folder:
   - `npm install`
   - Copy `.env.example` → `.env.local` and fill values from Firebase Console
   - `npm run dev`
3) Open http://localhost:3000

## Firebase
Create a Firebase project and add a **Web app** in Firebase Console.
Copy the config into `.env.local`.

