export default function Home() {
  return (
    <main className="stack">
      <div className="card stack">
        <h1 className="h1">Resonance</h1>
        <p className="small">Connection before appearance.</p>
        <p>This is a starter MVP web app scaffold. Use Onboarding to create an account and profile.</p>
        <div className="row">
          <a className="btn" href="/onboarding">Start onboarding</a>
          <a className="btn secondary" href="/app">Go to app</a>
        </div>
      </div>
    </main>
  );
}
