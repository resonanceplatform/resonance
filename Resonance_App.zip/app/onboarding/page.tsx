import Link from "next/link";
export default function Onboarding() {
  return (
    <main className="stack">
      <div className="card stack">
        <h2 className="h2">Resonance isn’t swipe dating.</h2>
        <p>You’ll connect through conversation before photos. If you’re here for something intentional, continue.</p>
        <div className="row">
          <Link className="btn" href="/onboarding/expectations">Continue</Link>
          <Link className="btn secondary" href="/">This isn’t for me</Link>
        </div>
      </div>
    </main>
  );
}
