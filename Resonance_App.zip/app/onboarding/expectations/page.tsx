import Link from "next/link";
export default function Expectations() {
  return (
    <main className="stack">
      <div className="card stack">
        <h2 className="h2">How Resonance works</h2>
        <ul>
          <li>A few thoughtful matches each day</li>
          <li>Conversation before appearance</li>
          <li>Mutual effort, always</li>
        </ul>
        <p className="small">Take your time. This isn’t a race.</p>
        <div className="row">
          <Link className="btn" href="/onboarding/auth">Continue</Link>
          <Link className="btn secondary" href="/onboarding">Back</Link>
        </div>
      </div>
    </main>
  );
}
