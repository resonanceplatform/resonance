import Link from "next/link";
export default function Verification() {
  return (
    <main className="stack">
      <div className="card stack">
        <h2 className="h2">Verification (placeholder)</h2>
        <p className="small">
          Integrate Persona or Stripe Identity here for ID + live selfie.
          Add “fresh selfie check” (timestamp + random prompt) and store it in Storage under fresh_checks/.
        </p>
        <div className="row">
          <Link className="btn" href="/app">Finish onboarding</Link>
          <Link className="btn secondary" href="/onboarding/profile">Back</Link>
        </div>
      </div>
    </main>
  );
}
