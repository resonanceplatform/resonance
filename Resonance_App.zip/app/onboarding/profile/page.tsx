"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { watchAuth } from "@/lib/auth";
import { listValues, upsertProfile } from "@/lib/db";

const PROMPTS = [
  "The values I won’t compromise on are…",
  "Something I’ve had to unlearn about relationships is…",
  "When I care about someone, it usually looks like…",
  "When there’s tension, I tend to… (and what helps)",
  "I’m here because I’m ready for…",
];

export default function ProfileSetup() {
  const [uid, setUid] = useState<string | null>(null);
  const [values, setValues] = useState<{id:string; name:string}[]>([]);
  const [picked, setPicked] = useState<string[]>([]);
  const [intent, setIntent] = useState("intentional dating");
  const [communicationStyle, setCommunicationStyle] = useState("reflective and direct");
  const [prompt, setPrompt] = useState(PROMPTS[1]);
  const [answer, setAnswer] = useState("I have learned the importance of clear communication.");
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => watchAuth(u => setUid(u?.uid ?? null)), []);
  useEffect(() => { (async () => setValues(await listValues()))(); }, []);

  function toggle(id: string) {
    setPicked(prev => prev.includes(id) ? prev.filter(x => x !== id) : (prev.length >= 3 ? prev : [...prev, id]));
  }

  async function save() {
    if (!uid) { setMsg("Please sign in first."); return; }
    await upsertProfile(uid, {
      userId: uid,
      intent,
      communicationStyle,
      promptAnswer: prompt + "\n\n" + answer,
      voiceNoteUrl: "",
      completionPercent: 80,
      readyToMatch: false,
      valueIds: picked,
    });
    setMsg("Profile saved.");
  }

  return (
    <main className="stack">
      <div className="card stack">
        <h2 className="h2">Identity-first profile</h2>
        {!uid && <p className="small" style={{ color: "#b91c1c" }}>You are not signed in. Go to Onboarding → Auth.</p>}

        <label className="small">Intent</label>
        <select className="input" value={intent} onChange={e => setIntent(e.target.value)}>
          <option value="serious relationship">A serious relationship</option>
          <option value="intentional dating">Intentional dating</option>
          <option value="figuring it out">I’m still figuring it out</option>
        </select>

        <label className="small">Communication style</label>
        <input className="input" value={communicationStyle} onChange={e => setCommunicationStyle(e.target.value)} />

        <div className="hr" />
        <p className="small">Pick 3 values.</p>
        <div className="row">
          {values.map(v => (
            <button key={v.id} className={"btn " + (picked.includes(v.id) ? "" : "secondary")} onClick={() => toggle(v.id)}>
              {v.name}
            </button>
          ))}
        </div>
        <p className="small">Selected: {picked.length}/3</p>

        <div className="hr" />
        <label className="small">Prompt</label>
        <select className="input" value={prompt} onChange={e => setPrompt(e.target.value)}>
          {PROMPTS.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        <label className="small">Your answer</label>
        <textarea className="input" style={{ minHeight: 90 }} value={answer} onChange={e => setAnswer(e.target.value)} />

        <div className="hr" />
        <div className="card stack" style={{ background: "#f9fafb" }}>
          <p className="small"><strong>Voice note (coming soon)</strong></p>
          <p className="small">Mobile app will record a 30–45 second voice note. Web scaffold includes Storage paths only.</p>
          <button className="btn secondary" disabled>Record voice note</button>
        </div>

        {msg && <div className="small">{msg}</div>}

        <div className="row">
          <button className="btn" onClick={save}>Save</button>
          <Link className="btn secondary" href="/onboarding/verification">Continue</Link>
        </div>
      </div>
    </main>
  );
}
