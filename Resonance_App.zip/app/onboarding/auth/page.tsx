"use client";
import { useState } from "react";
import Link from "next/link";
import { signInEmail, signUpEmail } from "@/lib/auth";
import { upsertUser } from "@/lib/db";

export default function AuthPage() {
  const [mode, setMode] = useState<"signup" | "signin">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [firstName, setFirstName] = useState("");
  const [age, setAge] = useState(30);
  const [city, setCity] = useState("Syracuse, NY");
  const [msg, setMsg] = useState<string | null>(null);

  async function submit() {
    setMsg(null);
    try {
      if (mode === "signup") {
        const cred = await signUpEmail(email, password);
        await upsertUser(cred.user.uid, { firstName: firstName || "Alex", age, city, email, status: "active" });
        setMsg("Account created.");
      } else {
        await signInEmail(email, password);
        setMsg("Signed in.");
      }
    } catch (e: any) {
      setMsg(e?.message ?? "Error");
    }
  }

  return (
    <main className="stack">
      <div className="card stack">
        <h2 className="h2">{mode === "signup" ? "Create your account" : "Sign in"}</h2>
        <div className="row">
          <button className={"btn " + (mode==="signup" ? "" : "secondary")} onClick={() => setMode("signup")}>Sign up</button>
          <button className={"btn " + (mode==="signin" ? "" : "secondary")} onClick={() => setMode("signin")}>Sign in</button>
        </div>

        {mode === "signup" && (
          <>
            <label className="small">First name</label>
            <input className="input" value={firstName} onChange={e => setFirstName(e.target.value)} placeholder="Alex" />
            <div className="row">
              <div style={{ flex: 1 }}>
                <label className="small">Age</label>
                <input className="input" type="number" value={age} onChange={e => setAge(Number(e.target.value))} />
              </div>
              <div style={{ flex: 2 }}>
                <label className="small">City</label>
                <input className="input" value={city} onChange={e => setCity(e.target.value)} />
              </div>
            </div>
          </>
        )}

        <label className="small">Email</label>
        <input className="input" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@email.com" />
        <label className="small">Password</label>
        <input className="input" value={password} onChange={e => setPassword(e.target.value)} type="password" placeholder="••••••••" />

        {msg && <div className="small">{msg}</div>}

        <div className="row">
          <button className="btn" onClick={submit}>Continue</button>
          <Link className="btn secondary" href="/onboarding/expectations">Back</Link>
          <Link className="btn secondary" href="/onboarding/profile">Profile</Link>
        </div>
      </div>
    </main>
  );
}
