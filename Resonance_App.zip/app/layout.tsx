import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Resonance",
  description: "Connection before appearance.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="container">
          <nav className="row" style={{ justifyContent: "space-between", marginBottom: 16 }}>
            <div className="row" style={{ gap: 8 }}>
              <span className="badge">Resonance</span>
              <span className="small">Connection before appearance.</span>
            </div>
            <div className="row">
              <a className="small" href="/onboarding">Onboarding</a>
              <a className="small" href="/app">App</a>
            </div>
          </nav>
          {children}
        </div>
      </body>
    </html>
  );
}
