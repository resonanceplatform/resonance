export default function Matches() {
  return (
    <main className="stack">
      <div className="card stack">
        <h2 className="h2">Daily matches (stub)</h2>
        <p className="small">Render curated match cards here (no photos initially) + match explanation.</p>

        <div className="card stack" style={{ background: "#f9fafb" }}>
          <div className="row" style={{ justifyContent: "space-between" }}>
            <strong>Jamie, 31 • Syracuse</strong>
            <span className="badge">Text-first</span>
          </div>
          <div className="small">Matched because you both value Growth and Honesty.</div>
          <div className="hr" />
          <div className="small"><strong>Prompt:</strong> Something I’ve had to unlearn…</div>
          <div>I used to confuse consistency with intensity. Now I look for calm effort.</div>
          <div className="hr" />
          <div className="row">
            <a className="btn" href="/app/chat">Message</a>
            <button className="btn secondary" disabled>Request photo unlock (later)</button>
          </div>
        </div>
      </div>
    </main>
  );
}
