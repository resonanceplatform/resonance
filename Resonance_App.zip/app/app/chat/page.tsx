export default function Chat() {
  return (
    <main className="stack">
      <div className="card stack">
        <h2 className="h2">Chat (stub)</h2>
        <p className="small">Text + voice notes first. Photos unlock later via mutual consent.</p>

        <div className="card stack" style={{ background: "#f9fafb" }}>
          <div className="small"><strong>Jamie:</strong> Hey — what values matter most to you right now?</div>
          <div className="small"><strong>You:</strong> Emotional safety and growth. I’m learning to communicate clearly.</div>
        </div>

        <textarea className="input" style={{ minHeight: 80 }} placeholder="Write a message…" />
        <div className="row">
          <button className="btn">Send (later)</button>
          <button className="btn secondary" disabled>Voice note (later)</button>
          <button className="btn secondary" disabled>Close conversation (later)</button>
        </div>
      </div>
    </main>
  );
}
