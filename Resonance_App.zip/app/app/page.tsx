"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { watchAuth, signOutUser } from "@/lib/auth";

export default function AppHome() {
  const [uid, setUid] = useState<string | null>(null);
  useEffect(() => watchAuth(u => setUid(u?.uid ?? null)), []);

  return (
    <main className="stack">
      <div className="card stack">
        <h2 className="h2">App (MVP shell)</h2>
        <p className="small">Next: daily matches feed + real chat + photo unlock gating.</p>
        <div className="row">
          <Link className="btn" href="/app/matches">Matches</Link>
          <Link className="btn secondary" href="/app/chat">Chat</Link>
        </div>
        <div className="hr" />
        <p className="small">Signed in as: {uid ?? "not signed in"}</p>
        <div className="row">
          <Link className="btn secondary" href="/onboarding/auth">Auth</Link>
          <button className="btn secondary" onClick={() => signOutUser()}>Sign out</button>
        </div>
      </div>
    </main>
  );
}
